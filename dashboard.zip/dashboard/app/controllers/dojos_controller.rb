class DojosController < ApplicationController
  def index
    @branches = Dojo.all
    @total = Dojo.all.count
  end

end
