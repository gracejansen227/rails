class DojosController < ApplicationController
  def index
    @branches = Dojo.all
    @total = Dojo.all.count
  end

  def create
    @dojo = Dojo.create(branch: params[:branch], street: params[:street], city: params[:city], state: params[:state])
    redirect_to ''
  end

  def new
  end

end
