class TimesController < ApplicationController
  def index
    @time = DateTime.current
    @newtime = Time.new
  end

end
